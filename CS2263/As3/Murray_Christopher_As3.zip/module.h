bool readQueries(FILE *f);
int compareStrs(const void * s1, const void * s2, void * arg);
int compareWeights(const void * s1, const void * s2, void * arg);
void sortQueries();
void printQueries();
